//
//  FlickrPhoto.swift
//  Test
//
//  Created by Bathanti on 8/15/17.
//  Copyright © 2017 Bathanti. All rights reserved.
//


import UIKit
class FlickrPhoto : NSObject
{
    var ImageFlick : UIImage!
    var Title : String!
    var Owner : String!
    
    override init()
    {
    }
    
}
